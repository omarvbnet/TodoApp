"use strict";
(() => {
var exports = {};
exports.id = 404;
exports.ids = [404];
exports.modules = {

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 9242:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: "localhost",
        database: "aledraak_contact",
        user: "aledraak_contact",
        password: "Vbnet2008ex@@"
    }
});
module.exports = mysql;


/***/ }),

/***/ 4343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ fetchAll)
/* harmony export */ });
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9242);
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_connect__WEBPACK_IMPORTED_MODULE_0__);

function rowArray(row) {
    var a = [];
    for(var m in row)a.push(row[m]);
    return a;
}
async function fetchAll(req, res) {
    await _connect__WEBPACK_IMPORTED_MODULE_0___default().query("select * from data", (err, rows, fields1)=>{
        if (!err) {
            const result = Object.values(JSON.parse(JSON.stringify(rows)));
            result.forEach((v)=>console.log(v.costDate));
            //console.log(rowArray(rows))
            return res.status(200).json(rows);
        } else {
            console.log(err.message);
        }
        _connect__WEBPACK_IMPORTED_MODULE_0___default().end();
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4343));
module.exports = __webpack_exports__;

})();