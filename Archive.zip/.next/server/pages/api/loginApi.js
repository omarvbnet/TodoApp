"use strict";
(() => {
var exports = {};
exports.id = 338;
exports.ids = [338];
exports.modules = {

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 9242:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const mysql = __webpack_require__(2261)({
    config: {
        host: "localhost",
        database: "aledraak_contact",
        user: "aledraak_contact",
        password: "Vbnet2008ex@@"
    }
});
module.exports = mysql;


/***/ }),

/***/ 3017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9242);
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_connect__WEBPACK_IMPORTED_MODULE_0__);

function login(request, response) {
    // Capture the input fields
    let username = request.body.username;
    let password = request.body.password;
    // Ensure the input fields exists and are not empty
    if (username && password) {
        // Execute SQL query that'll select the account from the database based on the specified username and password
        _connect__WEBPACK_IMPORTED_MODULE_0___default().query("SELECT * FROM users WHERE user_name = ? AND password = ?", [
            username,
            password
        ], function(error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) throw error;
            // If the account exists
            if (results.length > 0) {
                // Authenticate the user
                // Redirect to home page
                return response.status(203).json(username);
            } else {
                response.status(400).json("Incorrect Username and/or Password!");
            }
            response.end();
        });
    } else {
        response.send("Please enter Username and Password!");
        response.end();
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3017));
module.exports = __webpack_exports__;

})();