const mysql = require('serverless-mysql')({
  config: {
    host     :'localhost',
    database : 'aledraak_contact',
    user     : 'aledraak_contact',
    password : 'Vbnet2008ex@@'
  }
})

module.exports = mysql;